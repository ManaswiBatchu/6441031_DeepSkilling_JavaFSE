import React from 'react';
import './App.css';

function App() {
  const officeSpaces = [
    // {
    //   Name: "Beach Side Resort",
    //   Rent: 20000,
    //   Address: "Chennai",
    //   imgUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
    // },
    {
      Name: "Regus",
      Rent: 75000,
      Address: "Bangalore",
      imgUrl: "https://www.propertynz.co.nz/wp-content/uploads/2023/02/Empty_workspace-1.png",
    },
    {
      Name: "Beach Side Resort",
      Rent: 20000,
      Address: "Chennai",
      imgUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
    }
  ];

  return (
    <div style={{ textAlign: 'center', margin: '30px' }}>
      <h2>Office Space, at Affordable Range</h2>
      {officeSpaces.map((item, index) => {
        const rentColor = item.Rent <= 60000 ? 'textRed' : 'textGreen';
        return (
          <div key={index} style={{ marginBottom: '40px' }}>
            <img src={item.imgUrl} width="25%" height="150px" alt="Office Space" />
            <h2>Name: {item.Name}</h2>
            <h3 className={rentColor}>Rent: Rs. {item.Rent}</h3>
            <h3>Address: {item.Address}</h3>
          </div>
        );
      })}
    </div>
  );
}

export default App;
