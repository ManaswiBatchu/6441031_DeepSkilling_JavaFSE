import React, { useState } from "react";
import "./App.css"; // ✅ make sure you import this

import BookDetails from "./BookDetails";
import BlogDetails from "./BlogDetails";
import CourseDetails from "./CourseDetails";

export default function App() {
  const [showBooks, setShowBooks] = useState(true);
  const [showBlogs, setShowBlogs] = useState(true);
  const [showCourses, setShowCourses] = useState(true);

  const books = [
    { id: 1, bname: "Master React", price: 670 },
    { id: 2, bname: "Deep Dive into Angular 11", price: 800 },
    { id: 3, bname: "Mongo Essentials", price: 450 },
  ];

  return (
    <div className="App">
      <h1>Welcome to BloggerApp</h1>
      <button onClick={() => setShowBooks(!showBooks)}>Toggle Book Details</button>
      <button onClick={() => setShowBlogs(!showBlogs)}>Toggle Blog Details</button>
      <button onClick={() => setShowCourses(!showCourses)}>Toggle Course Details</button>

      <div className="container">
        {showCourses && <CourseDetails />}
        {showBooks && <BookDetails books={books} />}
        {showBlogs && <BlogDetails />}
      </div>
    </div>
  );
}
