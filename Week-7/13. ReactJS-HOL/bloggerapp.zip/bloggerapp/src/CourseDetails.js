import React from 'react';

const CourseDetails = () => {
  return (
    <div className="mystyle1">
      <h1>Course Details</h1>
      <h2>Angular</h2>
      <p>4/5/2021</p>
      <h2>React</h2>
      <p>6/3/2021</p>
    </div>
  );
};

export default CourseDetails;
