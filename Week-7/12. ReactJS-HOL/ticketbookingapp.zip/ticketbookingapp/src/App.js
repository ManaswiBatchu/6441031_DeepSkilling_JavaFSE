import React, { useState } from 'react';
import LoginButton from './components/LoginButton';
import LogoutButton from './components/LogoutButton';
import GuestPage from './components/GuestPage';
import UserPage from './components/UserPage';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLoginClick = () => setIsLoggedIn(true);
  const handleLogoutClick = () => setIsLoggedIn(false);

  let page, button;

  if (isLoggedIn) {
    page = <UserPage />;
    button = <LogoutButton onClick={handleLogoutClick} />;
  } else {
    page = <GuestPage />;
    button = <LoginButton onClick={handleLoginClick} />;
  }

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      {page}
      <br />
      {button}
    </div>
  );
}

export default App;
