import React from 'react';

function UserPage() {
  return (
    <div>
      <h2>Welcome!</h2>
    </div>
  );
}

export default UserPage;
