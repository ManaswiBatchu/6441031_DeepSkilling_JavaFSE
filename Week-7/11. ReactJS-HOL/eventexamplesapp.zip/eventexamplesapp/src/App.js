import React, { Component } from 'react';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
      amount: '',
      currency: ''
    };

    this.handleClick = this.handleClick.bind(this);
  }

  increment = () => {
    this.setState({ count: this.state.count + 1 });
    this.sayHello();
  };

  sayHello = () => {
    alert('Hello! Member1');
  };

  decrement = () => {
    this.setState({ count: this.state.count - 1 });
  };

  sayWelcome = (msg) => {
    alert(msg);
  };

  handleClick() {
    alert('I was clicked');
  }

  handleAmountChange = (e) => {
    this.setState({ amount: e.target.value });
  };

  handleCurrencyChange = (e) => {
    this.setState({ currency: e.target.value });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const rupees = this.state.amount;
    const euroValue = 80; // Static conversion rate
    const result = rupees * euroValue;
    alert(`Converting to ${this.state.currency} Amount is ${result}`);
  };

  render() {
    const formStyle = {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      gap: '10px',
      marginTop: '20px',
      width: '300px'
    };

    const labelStyle = {
      fontWeight: 'bold',
      marginBottom: '5px'
    };

    const inputStyle = {
      width: '100%',
      padding: '5px'
    };

    return (
      <div style={{ padding: '30px', fontFamily: 'Arial' }}>
        <h2>{this.state.count}</h2>
        <div style={{ marginBottom: '15px' }}>
          <button onClick={this.increment}>Increment</button>{' '}
          <button onClick={this.decrement}>Decrement</button>
        </div>

        <div style={{ marginBottom: '15px' }}>
          <button onClick={() => this.sayWelcome('welcome')}>Say welcome</button>
        </div>

        <div style={{ marginBottom: '25px' }}>
          <button onClick={this.handleClick}>Click on me</button>
        </div>

        <h1 style={{ color: 'green' }}>Currency Convertor!!!</h1>
        <form onSubmit={this.handleSubmit} style={formStyle}>
          <div style={{ width: '100%' }}>
            <label style={labelStyle}>Amount:</label>
            <input
              type="text"
              value={this.state.amount}
              onChange={this.handleAmountChange}
              style={inputStyle}
            />
          </div>
          <div style={{ width: '100%' }}>
            <label style={labelStyle}>Currency:</label>
            <textarea
              value={this.state.currency}
              onChange={this.handleCurrencyChange}
              style={{ ...inputStyle, height: '50px' }}
            ></textarea>
          </div>
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

export default App;
