import React from 'react';

function ListofPlayers({ players = [] }) {
  return (
    <div>
      <h2>All Players</h2>
      <ul>
        {players.map((player, index) => (
          <li key={index}>
            {player.name} - {player.country} - Score: {player.score}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ListofPlayers;
