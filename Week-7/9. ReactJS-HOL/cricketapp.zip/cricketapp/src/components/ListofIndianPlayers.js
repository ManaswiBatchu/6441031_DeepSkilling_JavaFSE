import React from 'react';

const ListofIndianPlayers = ({ players }) => {
  const indian = players.filter(player => player.country === 'India');
  return (
    <div>
      <h2>Indian Players</h2>
      <ul>
        {indian.map(p => (
          <li key={p.id}>{p.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default ListofIndianPlayers;
