import React from 'react';

function OddPlayers({ players = [] }) {
  const odd = players.filter((_, index) => index % 2 !== 0);

  return (
    <ul>
      {odd.map((player, index) => (
        <li key={index}>{player.name}</li>
      ))}
    </ul>
  );
}

export default OddPlayers; // ✅ MUST be default export
