import React from 'react';

function Scorebelow70({ players }) {
  const filtered = players.filter(player => player.score < 70);

  return (
    <div>
      <h2>Players with score below 70</h2>
      <ul>
        {filtered.map((player, index) => (
          <li key={index}>{player.name} - {player.score}</li>
        ))}
      </ul>
    </div>
  );
}

export default Scorebelow70;
