import React from 'react';
import ListofPlayers from './components/ListofPlayers';
import Scorebelow70 from './components/Scorebelow70';
import OddPlayers from './components/OddPlayers';
import EvenPlayers from './components/EvenPlayers';
import ListofIndianPlayers from './components/ListofIndianPlayers';

function App() {
  const players = [
    { name: 'Virat Kohli', country: 'India', score: 92 },
    { name: 'Steve Smith', country: 'Australia', score: 75 },
    { name: 'Rohit Sharma', country: 'India', score: 85 },
    { name: 'Joe Root', country: 'England', score: 66 },
    { name: 'KL Rahul', country: 'India', score: 48 },
  ];

  return (
    <div style={{ padding: '20px' }}>
      <h2></h2>
      <ListofPlayers players={players} />
      <hr />

      <h2></h2>
      <Scorebelow70 players={players} />
      <hr />

      <h2>Odd Players</h2>
      <OddPlayers players={players} />
      <hr />

      <h2>Even Players</h2>
      <EvenPlayers players={players} />
      <hr />

      <h2></h2>
      <ListofIndianPlayers players={players} />
      <hr />
    </div>
  );
}

export default App;
